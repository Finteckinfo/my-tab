> [!IMPORTANT]  
> This network is deprecated and is no longer being deployed to.

# Base Goerli

Chain ID: 84531

## LightAccountFactory

| Version | Address                                      | Explorer                                                                                   | Salt                                                                 | Run                                                                           |
| ------- | -------------------------------------------- | ------------------------------------------------------------------------------------------ | -------------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| v1.0.2  | `0x00000055C0b4fA41dde26A74435ff03692292FBD` | [explorer](https://goerli.basescan.org/address/0x00000055C0b4fA41dde26A74435ff03692292FBD) | `0x4e59b44847b379578588920ca78fbf26c0b4956c3406f3bdc271500000c2f72f` | [run](./broadcast/Deploy_LightAccountFactory.s.sol/84531/run-1699395850.json) |
| v1.0.1  | `0x000000893A26168158fbeaDD9335Be5bC96592E2` | [explorer](https://goerli.basescan.org/address/0x000000893A26168158fbeaDD9335Be5bC96592E2) | `0x7845d3459c316000001d6f83`                                         | [run](./broadcast/Deploy_LightAccountFactory.s.sol/84531/run-1696380309.json) |

## LightAccount

| Version | Address                                      | Explorer                                                                                   | Run                                                                           |
| ------- | -------------------------------------------- | ------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------- |
| v1.0.2  | `0x5467b1947F47d0646704EB801E075e72aeAe8113` | [explorer](https://goerli.basescan.org/address/0x5467b1947F47d0646704EB801E075e72aeAe8113) | [run](./broadcast/Deploy_LightAccountFactory.s.sol/84531/run-1699395850.json) |
| v1.0.1  | `0xc1b2fc4197c9187853243e6e4eb5a4af8879a1c0` | [explorer](https://goerli.basescan.org/address/0xc1b2fc4197c9187853243e6e4eb5a4af8879a1c0) | [run](./broadcast/Deploy_LightAccountFactory.s.sol/84531/run-1696380309.json) |
